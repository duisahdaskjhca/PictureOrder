<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

/**
 * 插件配置管理类
 * 
 * @package PictureOrder
 * @author 落花雨记
 */
class PictureOrder_Config
{
    /**
     * 默认配置参数
     * 
     * @var array
     */
    public static $defaults = array(
        'layoutMode' => 'auto',
        'baseColumns' => 3,
        'mobileColumns' => 2,
        'tabletColumns' => 2,
        'gapSize' => 8,
        'imageWidth' => 300,
        'imageHeight' => 200,
        'imageFit' => 'cover'
    );
    
    /**
     * 获取插件配置
     * 
     * @access public
     * @return object
     */
    public static function getOptions()
    {
        $options = Helper::options()->plugin('PictureOrder');
        
        // 确保所有配置项都有值
        foreach (self::$defaults as $key => $value) {
            if (!isset($options->$key)) {
                $options->$key = $value;
            }
        }
        
        return $options;
    }
    
    /**
     * 构建配置表单
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form
     * @return void
     */
    public static function configForm(Typecho_Widget_Helper_Form $form)
    {
        // 排版模式选择
        $layoutMode = new Typecho_Widget_Helper_Form_Element_Radio(
            'layoutMode',
            array(
                'auto' => _t('按插入数量排列（默认）'),
                'custom' => _t('自定义列数')
            ),
            self::$defaults['layoutMode'],
            _t('排版模式'),
            _t('选择图片排列方式，"按插入数量"将保持编辑时的横向数量')
        );
        $form->addInput($layoutMode);

        $baseColumns = new Typecho_Widget_Helper_Form_Element_Text(
            'baseColumns',
            null,
            self::$defaults['baseColumns'],
            _t('桌面端自定义列数'),
            _t('当排版模式为"自定义列数"时生效，默认为3')
        );
        $form->addInput($baseColumns->addRule('isInteger', _t('请输入有效的数字')));

        $mobileColumns = new Typecho_Widget_Helper_Form_Element_Text(
            'mobileColumns',
            null,
            self::$defaults['mobileColumns'],
            _t('手机端自定义列数'),
            _t('当排版模式为"自定义列数"时生效，默认为2')
        );
        $form->addInput($mobileColumns->addRule('isInteger', _t('请输入有效的数字')));

        $tabletColumns = new Typecho_Widget_Helper_Form_Element_Text(
            'tabletColumns',
            null,
            self::$defaults['tabletColumns'],
            _t('平板端自定义列数'),
            _t('当排版模式为"自定义列数"时生效，默认为2')
        );
        $form->addInput($tabletColumns->addRule('isInteger', _t('请输入有效的数字')));

        $gapSize = new Typecho_Widget_Helper_Form_Element_Text(
            'gapSize',
            null,
            self::$defaults['gapSize'],
            _t('图片间距(px)'),
            _t('请输入图片之间的间距，单位为像素，默认为8')
        );
        $form->addInput($gapSize->addRule('isInteger', _t('请输入有效的数字')));

        $imageWidth = new Typecho_Widget_Helper_Form_Element_Text(
            'imageWidth',
            null,
            self::$defaults['imageWidth'],
            _t('统一图片宽度(px)'),
            _t('所有图片将被调整为此宽度，单位为像素，默认为300')
        );
        $form->addInput($imageWidth->addRule('isInteger', _t('请输入有效的数字')));
        
        $imageHeight = new Typecho_Widget_Helper_Form_Element_Text(
            'imageHeight',
            null,
            self::$defaults['imageHeight'],
            _t('统一图片高度(px)'),
            _t('所有图片将被调整为此高度，单位为像素，默认为200')
        );
        $form->addInput($imageHeight->addRule('isInteger', _t('请输入有效的数字')));
        
        $imageFit = new Typecho_Widget_Helper_Form_Element_Radio(
            'imageFit',
            array(
                'cover' => _t('覆盖（裁剪图片以填充）'),
                'contain' => _t('包含（完整显示图片，可能有空白）'),
                'fill' => _t('填充（拉伸图片）')
            ),
            self::$defaults['imageFit'],
            _t('图片适应方式'),
            _t('选择图片如何适应统一尺寸')
        );
        $form->addInput($imageFit);

        // 插件使用方法
        $usage = new Typecho_Widget_Helper_Form_Element_Textarea(
            'usage',
            null,
            '在编辑器内使用
[photos]
![图片名称1-选填](图片1url)
![图片名称2-选填](图片2url)
![图片名称3-选填](图片3url)
[/photos]

如果插入3张图片，默认会横向显示3张，不受设备影响',
            _t('插件使用方法'),
            _t('在编辑器中使用上述格式插入图片组，插入数量决定横向显示数量。')
        );
        $usage->setAttribute('readonly', 'true');
        $form->addInput($usage);
    }
}
    