<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

/**
 * 图片处理辅助类
 * 
 * @package PictureOrder
 * @author 落花雨记
 */
class PictureOrder_Helper_Image
{
    /**
     * 从内容中提取图片
     * 
     * @access public
     * @param string $content 内容
     * @return array 图片数据数组
     */
    public static function extractImages($content)
    {
        $pattern = '/<img.*?src="(.*?)".*?alt="([^"]*)"*.*?>/i';
        preg_match_all($pattern, $content, $matches);

        if (empty($matches[1])) {
            return array();
        }

        // 构建图片数据数组
        $imageData = array();
        foreach ($matches[1] as $index => $src) {
            $alt = !empty($matches[2][$index]) ? $matches[2][$index] : '画廊图片';
            
            $imageData[] = array(
                'src' => htmlspecialchars($src),
                'alt' => htmlspecialchars($alt)
            );
        }
        
        return $imageData;
    }
    
    /**
     * 验证图片URL有效性
     * 
     * @access public
     * @param string $url 图片URL
     * @return bool 是否有效
     */
    public static function isValidImageUrl($url)
    {
        // 简单验证URL格式
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            return false;
        }
        
        // 检查是否是图片扩展名
        $extensions = array('jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp');
        $pathInfo = pathinfo($url);
        
        if (empty($pathInfo['extension'])) {
            return false;
        }
        
        return in_array(strtolower($pathInfo['extension']), $extensions);
    }
}
    