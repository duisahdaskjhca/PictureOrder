<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

/**
 * 布局处理辅助类
 * 
 * @package PictureOrder
 * @author 落花雨记
 */
class PictureOrder_Helper_Layout
{
    /**
     * 构建图片画廊HTML
     * 
     * @access public
     * @param array $images 图片数据
     * @param object $options 插件配置
     * @return string HTML内容
     */
    public static function buildGallery($images, $options)
    {
        // 处理配置参数
        $layoutMode = $options->layoutMode;
        $baseColumns = max(1, min(10, intval($options->baseColumns)));
        $mobileColumns = max(1, min(6, intval($options->mobileColumns)));
        $tabletColumns = max(1, min(8, intval($options->tabletColumns)));
        $gapSize = max(2, min(20, intval($options->gapSize)));
        $imageWidth = max(100, min(800, intval($options->imageWidth)));
        $imageHeight = max(100, min(800, intval($options->imageHeight)));
        $imageFit = $options->imageFit;

        // 确定列数
        $totalImages = count($images);
        $columns = $layoutMode === 'auto' ? $totalImages : $baseColumns;
        $mobileColumnsFinal = $layoutMode === 'auto' ? $totalImages : $mobileColumns;
        $tabletColumnsFinal = $layoutMode === 'auto' ? $totalImages : $tabletColumns;

        // 生成唯一ID用于样式隔离
        $galleryId = 'picture-order-' . uniqid();
        
        // 构建样式
        $style = self::buildStyle(
            $galleryId, 
            $columns, 
            $tabletColumnsFinal, 
            $mobileColumnsFinal, 
            $gapSize, 
            $imageWidth, 
            $imageHeight, 
            $imageFit,
            $totalImages
        );
        
        // 构建图片网格
        $grid = self::buildImageGrid($galleryId, $images, $mobileColumnsFinal, $totalImages);
        
        return $style . $grid;
    }
    
    /**
     * 构建画廊样式
     * 
     * @access private
     * @param string $galleryId 画廊ID
     * @param int $columns 桌面端列数
     * @param int $tabletColumns 平板端列数
     * @param int $mobileColumns 移动端列数
     * @param int $gapSize 间距
     * @param int $imageWidth 图片宽度
     * @param int $imageHeight 图片高度
     * @param string $imageFit 图片适应方式
     * @param int $totalImages 图片总数
     * @return string 样式HTML
     */
    private static function buildStyle($galleryId, $columns, $tabletColumns, $mobileColumns, 
                                      $gapSize, $imageWidth, $imageHeight, $imageFit, $totalImages)
    {
        // 仅在移动设备且图片较多时启用水平滚动
        $scrollClass = ($totalImages > $mobileColumns) ? 'horizontal-scroll' : '';
        
        $html = '<style>
            #' . $galleryId . ' {
                display: grid;
                grid-template-columns: repeat(' . $columns . ', 1fr);
                gap: ' . $gapSize . 'px;
                width: 100%;
                box-sizing: border-box;
                padding: 0;
                margin: 1rem 0;
                overflow: hidden;
            }
            
            #' . $galleryId . ' .gallery-item {
                break-inside: avoid;
                position: relative;
                height: ' . $imageHeight . 'px;
                margin: 0;
                padding: 0;
            }
            
            #' . $galleryId . ' img {
                width: 100%;
                height: 100%;
                object-fit: ' . $imageFit . ';
                border-radius: 4px;
                display: block;
                transition: all 0.3s ease;
                box-shadow: 0 2px 4px rgba(0,0,0,0.05);
            }
            
            #' . $galleryId . ' img:hover {
                transform: translateY(-3px);
                box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            }
            
            /* 平板设备响应式调整 */
            @media (max-width: 1024px) {
                #' . $galleryId . ' {
                    grid-template-columns: repeat(' . $tabletColumns . ', 1fr);
                }
            }
            
            /* 移动设备响应式调整 */
            @media (max-width: 767px) {
                #' . $galleryId . ' {
                    grid-template-columns: repeat(' . $mobileColumns . ', 1fr);
                    gap: ' . ($gapSize * 0.8) . 'px;
                }
                
                #' . $galleryId . '.horizontal-scroll {
                    overflow-x: auto;
                    overflow-y: hidden;
                    padding-bottom: 8px;
                    scrollbar-width: thin;
                    scrollbar-color: rgba(150, 150, 150, 0.3) transparent;
                }
                
                #' . $galleryId . '.horizontal-scroll::-webkit-scrollbar {
                    height: 6px;
                }
                
                #' . $galleryId . '.horizontal-scroll::-webkit-scrollbar-thumb {
                    background-color: rgba(150, 150, 150, 0.3);
                    border-radius: 3px;
                }
            }
            
            /* 图片加载动画 */
            #' . $galleryId . ' img {
                opacity: 0;
                animation: fadeIn-' . $galleryId . ' 0.5s ease forwards;
                animation-delay: calc(var(--animation-order) * 0.1s);
            }
            
            @keyframes fadeIn-' . $galleryId . ' {
                from { opacity: 0; transform: scale(0.98); }
                to { opacity: 1; transform: scale(1); }
            }
        </style>';
        
        return $html;
    }
    
    /**
     * 构建图片网格HTML
     * 
     * @access private
     * @param string $galleryId 画廊ID
     * @param array $images 图片数据
     * @param int $mobileColumns 移动端列数
     * @param int $totalImages 图片总数
     * @return string 图片网格HTML
     */
    private static function buildImageGrid($galleryId, $images, $mobileColumns, $totalImages)
    {
        $scrollClass = ($totalImages > $mobileColumns) ? 'horizontal-scroll' : '';
        $html = '<div id="' . $galleryId . '" class="picture-order ' . $scrollClass . '">';
        
        foreach ($images as $index => $image) {
            $html .= sprintf(
                '<div class="gallery-item" style="--animation-order: %d;">
                    <img src="%s" alt="%s">
                </div>',
                $index,
                $image['src'],
                $image['alt']
            );
        }
        
        $html .= '</div>';
        
        return $html;
    }
}
    