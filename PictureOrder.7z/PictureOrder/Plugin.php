<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

/**
 * 智能图片排版插件，支持统一图片尺寸显示和自定义布局
 * 
 * @package PictureOrder
 * @author 落花雨记
 * @version 1.0.0
 * @link http://www.luohuayu.cn
 */
class PictureOrder_Plugin implements Typecho_Plugin_Interface
{
    /**
     * 激活插件方法,如果激活失败,直接抛出异常
     * 
     * @access public
     * @return string
     * @throws Typecho_Plugin_Exception
     */
    public static function activate()
    {
        // 注册插件钩子
        Typecho_Plugin::factory('Widget_Abstract_Contents')->contentEx = array('PictureOrder_Plugin', 'parse');
        Typecho_Plugin::factory('Widget_Abstract_Contents')->excerptEx = array('PictureOrder_Plugin', 'parse');
        
        // 初始化必要目录
        self::initDir();
        
        return _t('插件启用成功');
    }
    
    /**
     * 禁用插件方法,如果禁用失败,直接抛出异常
     * 
     * @static
     * @access public
     * @return string
     * @throws Typecho_Plugin_Exception
     */
    public static function deactivate()
    {
        return _t('插件禁用成功');
    }
    
    /**
     * 获取插件配置面板
     * 
     * @static
     * @access public
     * @param Typecho_Widget_Helper_Form $form 配置面板
     * @return void
     */
    public static function config(Typecho_Widget_Helper_Form $form)
    {
        PictureOrder_Config::configForm($form);
    }
    
    /**
     * 个人用户的配置面板
     * 
     * @static
     * @access public
     * @param Typecho_Widget_Helper_Form $form
     * @return void
     */
    public static function personalConfig(Typecho_Widget_Helper_Form $form)
    {
        // 个人配置预留
    }
    
    /**
     * 解析内容中的图片短代码
     * 
     * @access public
     * @param string $content 内容
     * @param Widget_Abstract_Contents $widget 内容对象
     * @param string $lastResult 上一个结果
     * @return string
     */
    public static function parse($content, $widget, $lastResult)
    {
        $content = empty($lastResult) ? $content : $lastResult;
        
        // 检查是否包含photos短代码
        if (false === strpos($content, '[photos]')) {
            return $content;
        }

        // 匹配photos短代码
        $pattern = '/\[photos\](.*?)\[\/photos\]/s';
        return preg_replace_callback($pattern, array('PictureOrder_Action_Handler', 'parseCallback'), $content);
    }
    
    /**
     * 初始化插件所需目录
     * 
     * @access private
     * @return void
     */
    private static function initDir()
    {
        $dirs = array(
            __TYPECHO_PLUGIN_DIR__ . '/PictureOrder/cache'
        );
        
        foreach ($dirs as $dir) {
            if (!is_dir($dir)) {
                mkdir($dir, 0755, true);
            }
        }
    }
}

// 加载插件所需文件
require_once 'Config.php';
require_once 'Helper/Image.php';
require_once 'Helper/Layout.php';
require_once 'Action/Handler.php';
    