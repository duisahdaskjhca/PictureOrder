<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

/**
 * 插件动作处理类
 * 
 * @package PictureOrder
 * @author 落花雨记
 */
class PictureOrder_Action_Handler
{
    /**
     * 短代码解析回调函数
     * 
     * @access public
     * @param array $matches 匹配结果
     * @return string
     */
    public static function parseCallback($matches)
    {
        if (empty($matches[1])) {
            return '';
        }

        // 获取设置
        $options = PictureOrder_Config::getOptions();
        
        // 提取图片
        $images = PictureOrder_Helper_Image::extractImages($matches[1]);
        
        if (empty($images)) {
            return '';
        }

        // 构建图片网格HTML
        return PictureOrder_Helper_Layout::buildGallery($images, $options);
    }
}
    